int Z;

void main()
{
int a,b,c;
int p=6;
int q;


a=10;
b=20;

	c=a*b+25;

	p=6;

q=Z;
}
